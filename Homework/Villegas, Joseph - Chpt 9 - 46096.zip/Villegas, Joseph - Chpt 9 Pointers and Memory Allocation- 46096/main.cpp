#include <iostream>
#include <iomanip>

using namespace std;

int *getData(int &);     //Return the array size and the array
void prntDat(int *,int); //Print the integer array
int *dupArray (int *arr, int size);//duplicate the first int array;
void sortArray(int *array[], int size);
float *median(int *,int);//Fill the median Array with the Float array size, the median, and the integer array data
void prntMed(float *, int);   //Print the median Array

int main()
{
	//your code here
    int max;
    int *ptr = nullptr;
    float *med = nullptr;
    ptr = getData(max);
    
    prntDat(ptr, max);
    
    med = median(ptr,max);
    prntMed(med, max +2);
    
	return 0;
}

int *getData(int &size)
{
    int *numbers = nullptr;
    int count;
    
    cin >> size;
    
    if(size <= 0)
        return nullptr;
    
    numbers = new int [size];
    
    
    for ( count = 0; count < size; count++)
    {
        cin >> numbers[count];
    }  
    return numbers;
}
void prntDat(int *array,int size)
{
    for ( int i = 0; i < size; i++)
    {
        cout << array[i];
        if (i != size -1)
        {
            cout << " ";
        }
    }
    cout << endl;
}
float *median(int *array,int size)
{
    int *arrPtr[size];
    int newSize = size + 2;
    float *medium = new float [newSize];
    for (int i = 0; i<size; i++)
    {
        arrPtr[i] = &array[i];
    }
    
    medium[0] = newSize;
    sortArray(arrPtr, size);
    
    for (int i = 0; i<size; i++)
    {
        medium[i + 2] = array[i] ;
    }
    
    if (size % 2 != 0)
    {
        medium[1] = *arrPtr[size/2];
    }
    else
        medium[1] = (*arrPtr[(size-1)/2] + *arrPtr[size/2])/2.0;
    
    
    return medium;
}

void sortArray(int *arr[], int size)
{
    int startScan, minIndex;
    int *minElem;
    
    for(startScan = 0; startScan < (size-1); startScan++)
    {
        minIndex = startScan;
        minElem = arr[startScan];
        for (int i = startScan + 1; i < size ;i++)
        {
            if (*(arr[i]) < *minElem)
            {
                minElem = arr[i];
                minIndex = i;
            }
        }
        arr[minIndex] = arr[startScan];
        arr[startScan] = minElem;
    }
}
void prntMed(float *array, int size)
{
    cout << array[0] << " ";
    for (int i = 1; i < size; i++)
    {
        
        cout << fixed << showpoint << setprecision(2);
        cout << array[i];
        if (i != size -1)
        {
            cout << " ";
        }
    }
}
