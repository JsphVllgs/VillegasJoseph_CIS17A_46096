#include <iostream>

using namespace std;
int *getData(int &size);               //Fill the array
int *sort(const int *,int);       //Sort smallest to largest
int *reverse(const int *,int);  //Sort in reverse order
void prntDat(const int *,int); //Print the array

int main()
{
	//your code here
    int size;
    int *ptr = nullptr;
    int *sortPtr = nullptr;
    ptr = getData(size);
    sortPtr = sort(ptr, size);
    reverse(sortPtr, size);
    
	return 0;
}
int *getData(int &size)
{
    int *numbers = nullptr;
    int count;
    
    cin >> size;
    
    if(size <= 0)
        return nullptr;
    
    numbers = new int [size];
    
    
    for ( count = 0; count < size; count++)
    {
        cin >> numbers[count];
    }  
    return numbers;
}
int *sort(const int *arr, int size)
{ 
    int startScan, minIndex;
    int *newArray = nullptr;
    int *minElem;
    //int *arrPtr[size];
    
    newArray = new int[size];
    
    for (int i = 0; i<size; i++)
    {
        newArray[i] = arr[i];
    }
    
    for(startScan = 0; startScan < (size-1); startScan++)
    {
        minIndex = startScan;
        minElem = &newArray[startScan];
        for (int i = startScan + 1; i < size ;i++)
        {
            if (newArray[i] < *minElem)
            {
                minElem = &newArray[i];
                minIndex = i;
            }
        }
        newArray[minIndex] = newArray[startScan];
        newArray[startScan] = minElem;
    }
   
    for (int i = 0; i < size; i++)
    {
        newArray[i] = newArray[i];
    }
    
    return newArray;
}

int *reverse(const int *arr,int size)
{
    const int *max = arr+size;
    while (max > arr)
    {
        arr--;
        cout << *arr << " ";
    }
}