#include <cstdlib>
#include <iostream>
using namespace std;

    int month;
    int year;
    int numberOfDays;
    bool isLeapYear;

int main() 
{
    int month;
    int year;
    int numberOfDays;
    
    cout << "Enter a month (1-12): ";
    cin >> month;
    cout << "Enter the year: ";
    cin >> year;
 
    if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
    {
        numberOfDays = 31;
    }
    else if (month == 2)
        if (year % 100 == 0 && year % 400 == 0)
        {
           numberOfDays = 29;
        }
        else if (year % 100 != 0 && year % 4 == 0)
        {
            numberOfDays = 29;
        }
        else 
        {
            numberOfDays = 28;
        }
    
    else 
            numberOfDays = 30;
    
     cout << numberOfDays << " days";
    return 0;
}

