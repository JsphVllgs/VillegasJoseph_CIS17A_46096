
#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

 
int main() 
{
    double dollarAmount;
    double YEN_PER_DOLLAR = 107.72;
    double EUROS_PER_DOLLAR = 0.89;
    
    cout << "Enter the U.S. dollar amount: \n";
    cin >> dollarAmount;
    double yenAmount = dollarAmount * YEN_PER_DOLLAR;
    double euroAmount = dollarAmount * EUROS_PER_DOLLAR;
    cout << setprecision(2)<< fixed;
    cout << yenAmount << " Yen\n";
    cout << euroAmount << " Euros\n";
    return 0;
}

