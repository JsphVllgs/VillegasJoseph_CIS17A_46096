
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;



const int arrayCol = 30;
const int arrayRow = 3;

void getData (char conditions[][arrayCol]);
void getCount (const char conditions[][arrayCol]);
int getMostR(const int countR[]);
void printReport(const int countS[], const int totalS,const int countR[], 
                 const int totalR, const int countC[], const int totalC, 
                 const int monthName);

int main() 
{
    char conditions[arrayRow][arrayCol]={};
    
    getData(conditions);
    
    return 0;
}
void getData (char conditions[][arrayCol])
{
    ifstream inputFile;
    inputFile.open("RainOrShine.txt");
    for (int months = 0; months < arrayRow; months++)
    {
        for (int days = 0; days < arrayCol; days++)
        {
            inputFile >> conditions[months][days];
        }
        
    }
    getCount(conditions);
    inputFile.close();
    
}
void getCount (const char conditions[][arrayCol])
{
    int countS[arrayRow] = {},
        countR[arrayRow] = {},
        countC[arrayRow] = {};
    
    int totalS = 0,
        totalR = 0,
        totalC = 0,
        days = 0,
        months = 0,
        monthName = 0;
    
    for (months = 0; months < arrayRow; months++)
    {
        for (days = 0; days < arrayCol; days++)
        {
            conditions[months][days] == 'S' ? countS[months] += 1 : 
            conditions[months][days];
            
            conditions[months][days] == 'R' ? countR[months] += 1 : 
            conditions[months][days];
            
            conditions[months][days] == 'C' ? countC[months] += 1 : 
            conditions[months][days];
        }
        totalS += countS[months];
        totalR += countR[months];
        totalC += countC[months];
    }
    monthName = getMostR(countR);
    printReport(countS, totalS, countR, totalR, countC, totalC,monthName);
}
int getMostR(const int countR[])
{
    int monthName = 0, 
        largestAmount = 0, 
        months = 0;
    
    for (months = 0; months < arrayRow; months++)
    {
        if (countR[months] > largestAmount)
        {
            largestAmount = countR[months];
            monthName = months;
        }
    }
    return monthName;
}
void printReport(const int countS[], const int totalS,const int countR[], 
                 const int totalR, const int countC[], const int totalC, 
                 const int monthName)
{
    const int conditionCount = 3;

    const string monthStrings[arrayRow] = { "Jun", "Jul", "Aug"};
    char conditionType[conditionCount] = { 'S', 'R', 'C' }; 
    
    int months = 0;
    int x = 0;
    
    for(months = 0; months < arrayRow; months++)
    {
        cout << endl << monthStrings[months] << ":" << endl
             << "\n-------------------------------------------------\n";
        
        cout << "Sunny Days: "<< countS[months] << "\t";
        for (x = 0; x < countS[months]; x++)
        {
            cout << " " << conditionType[0];
        }
        cout << "\n-------------------------------------------------\n";
      
        cout << "Rainy Days: " << countR[months] << "\t";
        for (x = 0; x < countR[months]; x++)
        {
            cout << " " << conditionType[1]; 
        }
        cout << "\n-------------------------------------------------\n";
        cout << "Cloudy Days: " << countC[months] << "\t";
        for (x = 0; x < countC[months]; x++)
        {
            cout << " " << conditionType[2]; 
        }
        cout << "\n-------------------------------------------------\n";
    }
      
    cout << "\nMONTH WITH MOST RAIN:\n\n" << monthStrings[monthName] << "\n"
         << "-------------------------------------------------\n";
    for (months = 0; months < 1; months++)
    {
        cout << "Rainy Days: " << countR[monthName] << "\t";
        for (x = 0; x < countR[monthName]; x++)
        {
            cout << " " << conditionType[1];
        }
        cout << "\n-------------------------------------------------\n";
    }
}