#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

float celsius(float F);

int main() 
{
    float c = 0.0f;
    
    cout << "Fahrenheit             Celsius\n" 
         << "------------------------------------\n";
    cout << setprecision(2) << fixed; 
    
    for (int i = 0; i < 21; i++)
    {
       c = celsius(i);
        cout << i << "                    " << c << endl;
    }
    return 0;
}
float celsius(float f)
{
    float c = 0.0f;
    
    c = (f-32) * 5/9;
    
    return c;
}
