
#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

void inputCheck();
int duration;
int sizeStart;
float popIncrease;
float population = 0;

int main() 
{
    inputCheck();
    
    cout << "DAYS PASSED     TOTAL POPULATION\n"
         << "--------------------------------\n";
    
     
    for(int i = 0; i < duration; i++)
    {
        cout << (i+1) << "      " << population << endl;
        population = population + (population * popIncrease /100);
    }
    
    return 0;
}
void inputCheck()
{
    
    int error;
    
do 
    {
        error = 0;
        cout << "Enter the starting size of the population: ";
        cin >> population;
        if (population < 2 || !cin)
        {
            cout << "Invalid Response. Please enter an integer greater than 2.\n";
            error = 1;
            cin.clear();
            cin.ignore(80, '\n');
        }
    } while (error == 1);
do  
    {
        error = 0;
        cout << "Enter the average daily population increase(%): ";
        cin >> popIncrease;
        if (popIncrease < 0 || !cin)
        {
            cout << "Invalid Response. Please enter a percentage greater than 0.\n";
            error = 1;
            cin.clear();
            cin.ignore(80, '\n');
        }
    } while (error == 1);
    do  
    {
        error = 0;
        cout << "Enter the number of days they will multiply: ";
        cin >> duration;
        if (duration < 1 || !cin)
        {
            cout << "Invalid Response. Please enter an integer greater than 1.\n";
            error = 1;
            cin.clear();
            cin.ignore(80, '\n');
        }
    } while (error == 1);
}
