#include <iostream>
#include <string>

using namespace std;

int binarySearch(string array[], int numElems, string value);
void selectionSort(string names[], int size);
void showArray(string names[], int size);

int main() 
{
    int NUM_NAMES = 20;
    string names[NUM_NAMES] = {"Collins, Bill", "Smith, Bart", "Allen, Jim",
                               "Griffin, Jim", "Stamey, Marty", "Rose, Geri",
                               "Taylor, Terri", "Johnson, Jill", "Allison, Jeff",
                               "Looney, Joe", "Wolfe, Bill", "James, Jean",
                               "Weaver, Jim", "Pore, Bob", "Rutherford, Greg",
                               "Javens, Renee", "Harrison, Rose", "Setzer, Cathy",
                               "Pike, Gordon", "Holland, Beth"};
    
    string name;
    int results;
  
    cout << "Please enter an employee's name: "; 
    getline(cin, name); 

    selectionSort(names, NUM_NAMES);
    
    /*for viewing/verifying the sorted array
    for(int i = 0; i < NUM_NAMES - 1; i++)
    {
        cout << names[i] << "/ ";
    }*/
    
    results = binarySearch(names, NUM_NAMES, name);
    if (results == -1)
        cout << "That name does not exist in the array.\n";
    else
    {
        cout << "That name is found at element " << results;
        cout << " in the array.\n";
    }
    
    return 0;
}

void selectionSort(string names[], int size)
{
    int startScan,
        minIndex;
    string minValue;
    for (startScan = 0; startScan < size -1; startScan++)
    {
        minValue = names[startScan];
        minIndex = startScan;
        
        for(int index = startScan + 1; index < size; index++)
        {
            if (names[index] < minValue)
        {
            minValue = names[index];
            minIndex = index;
        }
        }
        
        names[minIndex] = names[startScan];
        names[startScan] = minValue;
    }
    
}

int binarySearch(string names[], int size, string value)
{
    int first = 0,
            last = size -1,
            middle,
            position = - 1;
    bool found = false;
    
    while (!found && first <+ last)
    {
        middle = (first + last) / 2;
        if(names[middle] == value)
        {
            found = true;
            position = middle;
        }
        else if (names[middle] > value)
            last = middle -1;
        else
            first = middle +1;
    }
    return position;
}


/*void showArray(string names[], int size)
{
    for(int i =0; i < size -1; i++)
    {
        cout << names[i] << "/ ";
    }
}*/