
#include <cstdlib>
#include <iostream>
using namespace std;

//Program to convert Celsius to Fahrenheit
int main() 
{
    double C;
    
    cout << "Enter temperature in Celsius. \n";
    cin >> C;
    double F = C * 9/5 + 32;
    cout << "It's " << F << " degrees Fahrenheit."; 
    return 0;
}

