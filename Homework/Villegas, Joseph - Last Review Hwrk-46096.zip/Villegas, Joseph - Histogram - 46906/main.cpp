#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main() 
{
    //Declare all Variables Here
    const int size = 4;
    char numbers[size]; 
         
    
    //Input or initialize values Here
    cout<<"Create a histogram chart."<<endl;
    cout<<"Input 4 digits as characters."<<endl;
    
    cin >> numbers;
    
    
    //for testing input
    
    for (int i = size -1; i>=0; i--)
    {
        if (isdigit(numbers[i]))
        {
        int starAmount = numbers[i] - '0';
        
        cout << starAmount << " ";
        for (int i = 1; i <= starAmount; i++)
        {
            cout << "*";
        }
        cout << endl;
        }
        else
            cout << numbers[i] << " ?\n";
    }
    
    
    //Histogram Here
    
    
    //Exit
    return 0;
}
