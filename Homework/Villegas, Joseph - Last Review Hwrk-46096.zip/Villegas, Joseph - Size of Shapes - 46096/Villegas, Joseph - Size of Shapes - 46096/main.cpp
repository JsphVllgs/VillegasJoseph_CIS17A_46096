#include <iostream>

using namespace std;


int main() 
{
    //Variables
    unsigned short x;
    char shape; //f-> forward b->backward x->cross
    
    //Input or initialize values Here
    cout<<"Create a numbered shape that can be sized."<<endl;
    cout<<"Input an integer number [1,50] and a character [x,b,f]."<<endl;
    cin>>x>>shape;
    
   //Draw the shape 
   switch (shape)
   {
       case 'x':
       case 'X':
       { 
           if(x % 2 == 0)
           {
            for (int row = 1; row <= x; row++)
            {
                for (int col = 1; col <=x; col++)
                {
                    if (row == col ||col == (x + 1) - row)
                    {
                        cout << x - (x-col);
                    }
                    else 
                    cout << " ";
                }
                cout << endl;
            }
           }
           else 
               for (int row = 1; row <= x; row++)
                {
                    for (int col = 1; col <=x; col++)
                    {
                        if (row == col ||col == (x + 1) - row)
                        {
                            cout << x - col + 1;
                        }
                        else 
                            cout << " ";
                    }
                    cout << endl;
                }
        break;
       }
       
       case 'b':
       case 'B':
       {
           if (x % 2 == 0)
            {
                for (int row = 1; row <= x; row++)
                {
                    for (int col = 1; col <=x; col++)
                    {
                        if (row == col)
                        {
                            cout << x - (x-col);
                        }
                        else 
                            cout << " ";
                    }
                    cout << endl;
                }
           }
           else
                for (int row = 1; row <= x; row++)
                {
                    for (int col = 1; col <=x; col++)
                    {
                        if (row == col)
                        {
                            cout << x - col + 1;
                        }
                        else 
                            cout << " ";
                    }
                    cout << endl;
                }
                    
        break;
       }
       
       case 'f':
       case 'F':
       {
           if (x % 2 == 0)
           {
            for (int row = 1; row <= x; row++)
            {
                for (int col = 1; col <=x; col++)
                {
                    if (col == x - row + 1)
                    {
                        cout << x-(x-col);
                    }
                    else 
                        cout << " ";
                }
                cout << endl;
            }
           }
           else
               for (int row = 1; row <= x; row++)
            {
                for (int col = 1; col <=x; col++)
                {
                    if (col == x - row + 1)
                    {
                        cout << x - col + 1;
                    }
                    else 
                cout << " ";
                }
                cout << endl;
            }
        break;
       }
   }
    
    
    
    //Exit
    return 0;
}