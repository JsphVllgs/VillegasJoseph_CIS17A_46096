
#include <iostream>
#include <iomanip>
using namespace std;

int main() 
{
    //Declare all Variables Here
    float payRate;
    float grossPay;
    float overtime;
    unsigned short hrsWrkd;
    const int firstCap = 20;
    const int secondCap = 40;
    
    
    //Input or initialize values Here
    cout<<"Paycheck Calculation."<<endl;
    cout<<"Input payRate in $'s/hour and hours worked"<<endl;
    cin>>payRate>>hrsWrkd;
    
    //Calculate Paycheck
    if (hrsWrkd <= firstCap)
    {
        grossPay = hrsWrkd * payRate;
    }
    else if (hrsWrkd > firstCap && hrsWrkd <secondCap)
    {
        overtime = hrsWrkd -firstCap;
        grossPay = overtime *(payRate * 1.5) + (payRate * firstCap);
    }  
    else if (hrsWrkd > secondCap)
    {
        overtime=(hrsWrkd - secondCap) ;
        grossPay = overtime * (payRate * 2.0)+(payRate * firstCap) + ((payRate *1.5) * firstCap);
    }
    //Output the check
    
    cout << fixed << setprecision(2);
    cout << "$" << grossPay << endl;
    //Exit
    return 0;
} 